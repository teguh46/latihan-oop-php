<?php

//jualan produk 
//komik
//game

//membuat class 
class Produk {
    public $judul, 
           $penulis,
           $penerbit,
           $harga;
    
    //membuat cosntructor function
    public function __construct
    ($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga"){
        $this ->judul = $judul;
        $this ->penulis = $penulis;
        $this ->penerbit = $penerbit;
        $this ->harga = $harga;
    }

    //membuat method
    public function getlabel(){
        return "$this->judul,
                $this->penulis, 
                $this->penerbit, 
                $this->harga";
    }
}

class CetakInfoProduk{
    public function cetak(Produk $Produk){
        $str = "{$Produk->getlabel()}";
        return $str;
    }
}

//membuat object

$produk1 = new Produk("Naruto", "Massahi Kishimoto", "Shonen Jump", "30000");
$produk2 = new Produk("Live soocer", "Thhodmrs", "Konami", "30000");
$produk3 = new Produk("One Piece", "Erichiro Oda", "Shonen Jump", "70000");


//cara memanggilnya

$infoproduk1 = new CetakInfoProduk();
echo "Komik : " . $infoproduk1 -> cetak($produk1);
echo "<br>";
echo "Game : " . $infoproduk1 -> cetak($produk2);

?>

