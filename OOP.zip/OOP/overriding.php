<?php

//jualan produk 
//komik
//game

//membuat class 
class Produk {
    public $judul, 
           $penulis,
           $penerbit,
           $harga;
    
    //membuat cosntructor function
    public function __construct
    ($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga"){
        $this ->judul = $judul;
        $this ->penulis = $penulis;
        $this ->penerbit = $penerbit;
        $this ->harga = $harga;
    }

    //membuat method
    public function getlabel(){
        return "$this->judul,
                $this->penulis, 
                $this->penerbit, 
                $this->harga";
    }

    public function getInfoProduk(){
        // Komik : Naruto, Massahi Kishimoto, Shonen Jump, 30000 - 100 Halaman
        // Game : Live soocer, Thhodmrs, Konami, 30000 ~ 50 Jam.

        $str = "{$this->getlabel()}";
        return $str;
    }
}

class Komik extends Produk {
    public $jmlHalaman;

    public function __constant($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga",  $jmlHalaman = 0){
      
        parent::__constant($judul, $penulis, $penerbit, $harga);

        $this->jmlHalaman = $jmlHalaman;
    }

    public function getInfoProduk() {
        $str = "Komik : " .parent::getInfoProduk() . " - {$this->jmlHalaman} Halaman.";
        return $str;
    }
}

class Game extends Produk{
    public $waktuMain;

    public function __constant($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga",  $waktuMain = 0){
       
        parent::__constant($judul, $penulis, $penerbit, $harga);

        $this->waktuMain = $waktuMain;
    }
      
    public function getInfoProduk() {
        $str = "Game : " .parent::getInfoProduk() . " ~ {$this->waktuMain} Jam.";
        return $str;
    }
}

class CetakInfoProduk{
    public function cetak(Produk $Produk){
        $str = "{$Produk->getlabel()}";
        return $str;
    }
}

//membuat object

$produk1 = new Komik("Naruto", "Massahi Kishimoto", "Shonen Jump", "30000", "100");
$produk3 = new Game("One Piece", "Erichiro Oda", "Shonen Jump", "70000", "50");

echo $produk1 ->getInfoProduk();
echo "<br>";
echo $produk3 ->getInfoProduk();

?>

