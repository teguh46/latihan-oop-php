<?php

//jualan produk 
//komik
//game

//membuat class 
class Produk {
    public $judul, 
           $penulis,
           $penerbit,
           $harga;
    
    //membuat cosntructor function
    public function __construct
    ($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga"){
        $this ->judul = $judul;
        $this ->penulis = $penulis;
        $this ->penerbit = $penerbit;
        $this ->harga = $harga;
    }

    //membuat method
    public function getlabel(){
        return "$this->judul,
                $this->penulis, 
                $this->penerbit, 
                $this->harga";
    }
}

//membuat object

$produk1 = new Produk("Naruto", "Massahi Kishimoto", "Shonen Jump", "30000");
$produk2 = new Produk("Live soocer", "Thhodmrs", "Konami", "30000");
$produk3 = new Produk("One Piece", "Erichiro Oda", "Shonen Jump", "70000");


//cara memanggilnya
echo "komik : " . $produk1->getlabel();
echo "<br>";
echo "komik : " . $produk3->getlabel();
echo "<br>";
echo "Game : " . $produk2->getlabel();
?>

