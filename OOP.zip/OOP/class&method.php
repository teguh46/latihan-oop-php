<?php

//jualan produk 
//komik
//game

//membuat class 
class Produk {
    //memuat properti yang isinya judul, penulis, penerbit, dan harga
    public $judul = "judul", 
           $penulis = "penulis",
           $penerbit = "penerbit",
           $harga = 0;

    //membuat method
    //method adalah function yang ada didalam class
    //karena lingkup variabel scope jadi ditambah keyword $this untuk mengambil isi dari properti yang ada di dalam class yang bersangkutan ketika di buat instance
    public function getlabel(){
        return "$this->judul, $this->penulis, $this->penerbit, $this->harga";
    }
}

//membuat object
//membuat variabel diisi dengan new class
$produk1 = new Produk(); //object komik
           $produk1->judul = "Naruto";
           $produk1->penulis ="Massashi Kishimoto";
           $produk1->penerbit ="Shonen Jump";
           $produk1->harga = 10000;

$produk2 = new Produk(); //object game
           $produk2->judul = "live soccer";
           $produk2->penulis = "Thomeas";
           $produk2->penerbit = "konami";
           $produk2->harga = 20000;

echo "komik : " . $produk1->getlabel();
echo "<br>";
echo "Game : " . $produk2->getlabel();
?>

