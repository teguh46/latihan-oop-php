<?php
require_once 'App/init.php';

// $produk1 = new Komik("Naruto", "Massahi Kishimoto", "Shonen Jump", "30000", "100");
// $produk2 = new Game("One Piece", "Erichiro Oda", "Shonen Jump", "70000", "50");

// $cetakProduk = new CetakInfoProduk();
// $cetakProduk->tambahProduk($produk1);
// $cetakProduk->tambahProduk($produk2);

// echo $cetakProduk->cetak();

//menggunakan alias atau nama lain
use App\Service\User as ServiceUser;
use App\Produk\User as ProdukUser;

new ServiceUser();
echo "<br>";
new ProdukUser();