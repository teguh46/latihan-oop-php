<?php

// //tidak bisa simpan didalam class
// define('NAMA', 'TEGUH SUBAGYO');
// echo NAMA;
// echo "<br>";

// //bisa dimasukan kedalam class
// const UMUR = 24;
// echo UMUR;

class coba {
    const NAMA = 'TEGUH SUBAGYO';
}

echo coba::NAMA;