<?php

//jualan produk 
//komik
//game

//membuat class 
class Produk {
    public $judul, 
           $penulis,
           $penerbit,
           $harga,
           $jmlHalaman,
           $WaktuMain;
    
    //membuat cosntructor function
    public function __construct
    ($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga", $jmlHalaman = 0, $WaktuMain = 0){
        $this ->judul = $judul;
        $this ->penulis = $penulis;
        $this ->penerbit = $penerbit;
        $this ->harga = $harga;
        $this ->jmlHalaman = $jmlHalaman;
        $this ->waktuMain = $WaktuMain;
    }

    //membuat method
    public function getlabel(){
        return "$this->judul,
                $this->penulis, 
                $this->penerbit, 
                $this->harga";
    }

    public function getInfoProduk(){
        // Komik : Naruto, Massahi Kishimoto, Shonen Jump, 30000 - 100 Halaman
        // Game : Live soocer, Thhodmrs, Konami, 30000 ~ 50 Jam.

        $str = "{$this->getlabel()}";
        return $str;
    }
}

class Komik extends Produk {
    public function getInfoProduk() {
        $str = "Komik : {$this->getlabel()} - {$this->jmlHalaman} Halaman.";
        return $str;
    }
}

class Game extends Produk{
    public function getInfoProduk() {
        $str = "Game : {$this->getlabel()} ~ {$this->waktuMain} Jam.";
        return $str;
    }
}

class CetakInfoProduk{
    public function cetak(Produk $Produk){
        $str = "{$Produk->getlabel()}";
        return $str;
    }
}

//membuat object

$produk1 = new Komik("Naruto", "Massahi Kishimoto", "Shonen Jump", "30000", "100", "0");
$produk3 = new Game("One Piece", "Erichiro Oda", "Shonen Jump", "70000", "0", "50");

echo $produk1 ->getInfoProduk();
echo "<br>";
echo $produk3 ->getInfoProduk();

?>

