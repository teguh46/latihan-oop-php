<?php

//jualan produk 
//komik
//game

//membuat class 
class Produk {
    private $judul, 
           $penulis,
           $penerbit,
           $harga,
           $diskon = 0;
    
    //membuat cosntructor function
    public function __construct
    ($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga"){
        $this ->judul = $judul;
        $this ->penulis = $penulis;
        $this ->penerbit = $penerbit;
        $this ->harga = $harga;
    }

    public function setJudul ($judul){

        // if (!is_string ($judul)){
        //     throw new exception("judul harus string");
        // }
        $this->judul = $judul;
    }

    public function getJudul(){
        return $this->judul;
    }

    public function setPenulis ($penulis){
        $this->penulis = $penulis;
    }

    public function getPenulis(){
        return $this->penulis;
    }

    public function setPenerbit ($penerbit){
        $this->penerbit = $penerbit;
    }

    public function getPenerbit (){
        return $this->penerbit;
    }

    public function setHarga ($harga){
        $this->harga = $harga;
    }
    
    public function setDiskon ($diskon){
        $this->diskon = $diskon;
    }

    public function getDiskon (){
        return $this->diskon;
    }

    //membuat method
    public function getlabel(){
        return "$this->judul,
                $this->penulis, 
                $this->penerbit, 
                $this->harga";
    }

    public function getHarga(){
        return $this->harga - ($this->harga * $this->diskon / 100);
    }

    public function getInfoProduk(){
        // Komik : Naruto, Massahi Kishimoto, Shonen Jump, 30000 - 100 Halaman
        // Game : Live soocer, Thhodmrs, Konami, 30000 ~ 50 Jam.

        $str = "{$this->getlabel()}";
        return $str;
    }
}

class Komik extends Produk {
    public $jmlHalaman;

    public function __constant($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga",  $jmlHalaman = 0){
      
        parent::__constant($judul, $penulis, $penerbit, $harga);

        $this->jmlHalaman = $jmlHalaman;
    }

    public function getInfoProduk() {
        $str = "Komik : " .parent::getInfoProduk() . " - {$this->jmlHalaman} Halaman.";
        return $str;
    }
}

class Game extends Produk{
    public $waktuMain;

    public function __constant($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga",  $waktuMain = 0){
       
        parent::__constant($judul, $penulis, $penerbit, $harga);

        $this->waktuMain = $waktuMain;
    }

    public function getInfoProduk() {
        $str = "Game : " .parent::getInfoProduk() . " ~ {$this->waktuMain} Jam.";
        return $str;
    }
}

class CetakInfoProduk{
    public function cetak(Produk $Produk){
        $str = "{$Produk->getlabel()}";
        return $str;
    }
}

//membuat object

$produk1 = new Komik("Naruto", "Massahi Kishimoto", "Shonen Jump", "30000", "100");
$produk3 = new Game("One Piece", "Erichiro Oda", "Shonen Jump", "70000", "50");

echo $produk1 ->getInfoProduk();
echo "<br>";
echo $produk3 ->getInfoProduk();

echo "<hr>";

$produk3->setDiskon(50);
echo $produk3->getHarga();

echo "<hr>";

$produk1->setJudul("one piece"); //setter
echo $produk1->getJudul(); //getter
echo "<br>";
echo $produk1->getPenulis();
echo "<br>";
echo $produk1->getPenerbit();
echo "<br>";
echo $produk1->getHarga();
echo "<br>";
echo $produk1->getDiskon();

?>

