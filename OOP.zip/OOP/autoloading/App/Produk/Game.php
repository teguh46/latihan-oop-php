<?php

class Game extends Produk implements InfoProduk{
    public $waktuMain;

    public function __constant($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga",  $waktuMain = 0){
       
        parent::__constant($judul, $penulis, $penerbit, $harga);

        $this->waktuMain = $waktuMain;
    }

    public function getInfo(){
        // Komik : Naruto, Massahi Kishimoto, Shonen Jump, 30000 - 100 Halaman
        // Game : Live soocer, Thhodmrs, Konami, 30000 ~ 50 Jam.

        $str = "{$this->getlabel()}";
        return $str;
    }

    public function getInfoProduk() {
        $str = "Game : " .$this->getInfo() . " ~ {$this->waktuMain} Jam.";
        return $str;
    }
}