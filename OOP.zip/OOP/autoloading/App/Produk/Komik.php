<?php

class Komik extends Produk implements InfoProduk{
    public $jmlHalaman;

    public function __constant($judul="judul", $penulis="penulis", $penerbit="penerbit", $harga="harga",  $jmlHalaman = 0){
      
        parent::__constant($judul, $penulis, $penerbit, $harga);

        $this->jmlHalaman = $jmlHalaman;
    }

    public function getInfo(){
        // Komik : Naruto, Massahi Kishimoto, Shonen Jump, 30000 - 100 Halaman
        // Game : Live soocer, Thhodmrs, Konami, 30000 ~ 50 Jam.

        $str = "{$this->getlabel()}";
        return $str;
    }

    public function getInfoProduk() {
        $str = "Komik : " .$this->getInfo() . " - {$this->jmlHalaman} Halaman.";
        return $str;
    }
}