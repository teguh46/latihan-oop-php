<?php

class contohStatic{
    public static $angka = 1;
    
    public static function halo(){
        return "halo " . self::$angka . " kali";
    }
}

echo contohStatic :: $angka;
echo "<br>";
echo contohStatic :: halo();
echo "<hr>";
echo contohStatic :: halo();
